<div align="center">
<img src="https:https://images4.alphacoders.com/641/641968.jpg" alt="FADHIL BOT" width="500" />


<h3 align="center">Made with ❤️ by</h3>
<p align="center">
  <a href="https://github.com/MrK4ZUT0"><img src="https://avatars.githubusercontent.com/u/76678504?s=400&u=85145113789bd1b2db84778ce7eefc30aa017383&v=4" height="128" width="128" /></a>
  <a href="https://github.com/affisjunianto"><img src="https://j.top4top.io/p_18503y4jm1.jpg" height="128" width="128" /></a>
 </p>
  
## INSTALLATION

```bash
> pkg update && pkg upgrade
> apt-get update
> apt-get upgrade
> pkg install git
> pkg install bash
> git clone https://github.com/MrK4ZUT0/botwa
> cd botwa
> bash install.sh
> node index.js
```

Scan the qr code that appears, using whatsapp web!



## SOCIAL MEDIA

* [INSTAGRAM FADHIL](https://instagram.com/nur.fdhl)
* [GROUP WHATSAPP](https://chat.whatsapp.com/IOH07I8Ud9R46soSkt2EB7)
* [GROUP TELEGRAM](https://t.me/joinchat/FT_-G7e136-CWXTM)
* [WHATSAPP](https://api.whatsapp.com/send?phone=6288221608614&text=Assalamualaikum)
* [YOUTUBE](https://youtube.com/channel/UCdQHlF_G7XUaPCSHw-WMS0g)
* [TWITTER](https://twitter.com/nurfdhl_)
* [INSTAGRAM AFFIS](https://Instagram.com/affis_saputro123)

## FEATURE

| Owner Bot Only  |              Feature                |
| :------------: | :---------------------------------------------: |
|         ✅          |   Leave all group                   |
|         ✅          |   Maker Menu                    |
|         ✅          |   Broadcast                      |
|         ✅          |   Getses                      |
|         ✅          |   Sticker                      |
|         ✅          |   Games                                |
|         ✅          |   Pinterest                          |
|         ✅          |   Avengers                            |
|         ✅          |   Block                      |
|         ✅          |   Unblock                      |
|         ✅          |   Leveling                        |
|         ✅          |   Set Prefix                      |
|         ✅          |   Limit                          |
|         and        |  Others...                     |
| New feature |  Coming Soon...             |

---

## SPECIAL THANGKS TO🤝
* [ALLAH SWT]
* [AFFIS JUNIANTO](https://github.com/affisjunianto/botwasapv3)
* [MAHANKBARBAR](https://github.com/MhankBarBar)
* [FADHIL GRAPHY2](https://github.com/FdhlGraphy)
