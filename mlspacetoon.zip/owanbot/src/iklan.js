const iklan = () => { 
	return `           
╭◪ *IKLAN*
╰──────────────────────
├❍ *DAFTAR SEWA BOT :*
├❍ *SEWA : ??K/GRUP (BULAN)*
├❍ *SEWA : ??K (1 TAHUN)*
├❍ *PEMBAYARAN BISA MELALUI :*
├❍ *GOPAY, DANA, PULSA, SAWERIA*
╰──────────────────────
╭◪ *KEUNTUNGAN SEWA BOT :*
╰──────────────────────
├❍ *1. BISA MENJADI ADMIN Hazzelnut*
├❍ *2. BISA MENDAPATKAN COMMAND ADMIN*
╰──────────────────────
╭◪ *KEUNTUNGAN BUAT BOT :*
╰──────────────────────
├❍ *1. BISA MENJADI OWNER BOT SENDIRI*
├❍ *2. BISA MENGGANTI NAMA BOT SENDIRI
├❍ *3. BISA MEMBAWA BOT KE GROUP*
├❍ *4. BISA MENGGUNAKAN COMMAND OWNER*
├❍ *5. BISA MENYEWAKAN BOT KEMBALI*
╰──────────────────────
╭◪ *JIKA MINAT IKLAN DIATAS*
╰──────────────────────
├❍ *HARAP HUBUNGI NOMOR DIBAWAH :*
├❍ *wa.me/6285794065296*
╰───────────〘 WANBYONE BOT M19 〙
`
}
exports.iklan = iklan